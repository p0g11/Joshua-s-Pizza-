function sample1 (){
    alert ("Welcome to Joshua's Pizza");
    }
    function submit(){
        alert ("Thank you for filling up. We will update your order as soon as possible.");
    }
  

   